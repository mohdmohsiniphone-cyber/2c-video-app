# 2C Video — Free AI Video Generator

Yeh ek chhoti web app hai: aap prompt likhte hain, yeh Hugging Face ke
**free** text-to-video model se asli video banwa kar dikhati hai.

## Yeh free kyun/kaise hai
- Model: `ali-vilab/text-to-video-ms-1.7b` (open, free) Hugging Face ke
  Inference API par.
- Free tier hai — rate-limited hai, aur model "cold" hone par pehli
  request thodi slow (30-90 sec) ho sakti hai. Yeh koi bug nahi, free
  tier ka normal behaviour hai.
- Koi credit card, koi Anthropic/OpenAI billing yahan involved nahi hai.

## Setup (ek baar karna hai) — 10 minute lagenge

### Step 1 — Hugging Face free account + token
1. https://huggingface.co par free signup karein.
2. Settings → Access Tokens → "New token" → type: **Read** → banayein.
3. Token copy kar lein (kuch is tarah dikhega: `hf_xxxxxxxxxxxx`).

### Step 2 — Vercel par free deploy
1. https://vercel.com par free signup karein (GitHub se login easy hai).
2. Is poore folder (`2c-video-app`) ko apne GitHub account mein ek naye
   repo mein upload/push kar dein.
3. Vercel dashboard mein "Add New Project" → apna GitHub repo select
   karein → Deploy dabayein.
4. Deploy hone ke baad: Project → Settings → Environment Variables
   → naya variable add karein:
   - Name: `HF_TOKEN`
   - Value: (aapka Hugging Face token, jo Step 1 mein copy kiya tha)
5. Environment variable add karne ke baad ek baar phir se "Redeploy"
   dabayein (taaki naya variable apply ho jaye).

### Step 3 — Use karein
Vercel aapko ek live link dega (jaise `https://2c-video.vercel.app`).
Woh link kholein, scene likhein, "Generate video" dabayein.

## Limits (in-built, jaan-boojh kar)
- Har prompt max 500 characters ka ho sakta hai.
- Video length model khud decide karta hai (chhoti clips, ~2-4 sec) —
  free tier mein length customize karna support nahi karta.
- Free tier rate-limited hai: agar bahut jaldi-jaldi bahut saari
  requests bhejenge, Hugging Face temporarily block kar sakta hai.
  Thoda ruk kar dobara try karein.

## Agar behtar/tez video chahiye ho (paid upgrade, optional)
`api/generate.js` file mein `MODEL_ID` line ko kisi paid model
(jaise Runway, Luma, Kling) ke API se replace kar sakte hain — us
company ki apni pricing/API docs follow karni hogi.
