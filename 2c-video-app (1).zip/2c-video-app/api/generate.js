// api/generate.js
// Vercel serverless function: receives a text prompt from the frontend,
// calls Hugging Face's free Inference API for a text-to-video model,
// and streams the resulting video (MP4) back to the browser.
//
// Your Hugging Face token stays here on the server. It is never sent to
// the browser, which is what keeps it safe.

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Use POST' });
    return;
  }

  const { prompt } = req.body || {};
  if (!prompt || typeof prompt !== 'string' || !prompt.trim()) {
    res.status(400).json({ error: 'Missing "prompt" in request body' });
    return;
  }

  const HF_TOKEN = process.env.HF_TOKEN;
  if (!HF_TOKEN) {
    res.status(500).json({
      error: 'Server is missing HF_TOKEN. Add it in your Vercel project settings (Environment Variables).'
    });
    return;
  }

  // Free, open text-to-video model on Hugging Face's Inference API.
  // You can swap this for another free text-to-video model id if you like.
  const MODEL_ID = 'ali-vilab/text-to-video-ms-1.7b';

  try {
    const hfResponse = await fetch(
      `https://api-inference.huggingface.co/models/${MODEL_ID}`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${HF_TOKEN}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ inputs: prompt }),
      }
    );

    if (!hfResponse.ok) {
      const errText = await hfResponse.text();
      // Hugging Face returns 503 while a free-tier model is "cold starting" —
      // tell the frontend so it can show a friendly "warming up, try again" message.
      res.status(hfResponse.status).json({
        error: 'Hugging Face API error',
        detail: errText,
        cold_start: hfResponse.status === 503,
      });
      return;
    }

    const contentType = hfResponse.headers.get('content-type') || 'video/mp4';
    const arrayBuffer = await hfResponse.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    res.setHeader('Content-Type', contentType);
    res.status(200).send(buffer);
  } catch (err) {
    res.status(500).json({ error: 'Server error calling Hugging Face', detail: String(err) });
  }
}
